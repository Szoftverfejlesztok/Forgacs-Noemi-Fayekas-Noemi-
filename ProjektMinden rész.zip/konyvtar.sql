-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Ápr 20. 18:47
-- Kiszolgáló verziója: 10.4.28-MariaDB
-- PHP verzió: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `konyvtar`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `helye`
--

CREATE TABLE `helye` (
  `id` int(11) NOT NULL,
  `konyvId` int(11) NOT NULL,
  `reszleg` varchar(255) NOT NULL,
  `polc` varchar(255) NOT NULL,
  `sor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `helye`
--

INSERT INTO `helye` (`id`, `konyvId`, `reszleg`, `polc`, `sor`) VALUES
(1, 1, 'Horror', '1', 1),
(2, 2, 'Horror', '1', 2),
(3, 3, 'Romantikus', '1', 1),
(4, 4, 'Romantikus', '1', 2),
(5, 5, 'Romantikus', '1', 3),
(6, 6, 'Történelmi', '1', 1),
(7, 7, 'Történelmi', '1', 2),
(8, 8, 'Történelmi', '1', 3),
(9, 9, 'Sci-fi', '1', 1),
(10, 10, 'Sci-fi', '1', 2),
(11, 11, 'Sci-fi', '1', 3),
(12, 12, 'Irodalom', '1', 1),
(13, 13, 'Irodalom', '1', 2),
(14, 14, 'Irodalom', '1', 3),
(15, 15, 'Történelmi, Ismeretterjesztő', '1', 4),
(16, 16, 'Filozófiai, Gyermekirodalom', '1', 1),
(17, 17, 'Gasztronómia', '1', 1),
(18, 18, 'Gasztronómia', '1', 2),
(19, 19, 'Gasztronómia', '1', 3),
(20, 20, 'Képregény', '1', 1),
(21, 21, 'Képregény', '1', 2),
(22, 22, 'Horror', '1', 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kolcsonzes`
--

CREATE TABLE `kolcsonzes` (
  `id` int(11) NOT NULL,
  `konyvId` int(11) NOT NULL,
  `kolcsonzoId` int(11) NOT NULL,
  `datumKi` date NOT NULL,
  `datumBe` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `kolcsonzes`
--

INSERT INTO `kolcsonzes` (`id`, `konyvId`, `kolcsonzoId`, `datumKi`, `datumBe`) VALUES
(1, 2, 1, '2025-03-13', '2025-03-19'),
(2, 1, 1, '2025-03-19', '2025-03-19'),
(3, 1, 1, '2025-03-19', '2025-03-19'),
(4, 3, 1, '2025-03-19', '2025-03-20'),
(5, 7, 1, '2025-02-05', '2025-03-19'),
(7, 2, 1, '2025-03-18', '2025-03-19'),
(8, 1, 1, '2025-01-02', NULL),
(9, 13, 2, '2025-04-10', '2025-04-11');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kolcsonzo`
--

CREATE TABLE `kolcsonzo` (
  `kolcsonzoId` int(11) NOT NULL,
  `nev` varchar(255) NOT NULL,
  `telepules` varchar(255) NOT NULL,
  `szuletesidatum` date NOT NULL,
  `belepesdatum` date NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefonszam` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `kolcsonzo`
--

INSERT INTO `kolcsonzo` (`kolcsonzoId`, `nev`, `telepules`, `szuletesidatum`, `belepesdatum`, `email`, `telefonszam`) VALUES
(1, 'Forgács Noémi', 'Szeged', '2006-08-18', '2025-03-01', 'forgacsnoemi3@gmail.com', 2147483647),
(2, 'Csipei Szintia', 'Kübekháza', '2007-12-06', '2025-04-10', 'csipeisziszi@gmail.com', 2147483647);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `konyv`
--

CREATE TABLE `konyv` (
  `konyvId` int(11) NOT NULL,
  `cim` varchar(255) NOT NULL,
  `szerzo` varchar(255) NOT NULL,
  `peldanyszam` int(11) NOT NULL,
  `kiadEv` year(4) NOT NULL,
  `leiras` text DEFAULT NULL,
  `keszleten` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `konyv`
--

INSERT INTO `konyv` (`konyvId`, `cim`, `szerzo`, `peldanyszam`, `kiadEv`, `leiras`, `keszleten`) VALUES
(1, 'Az', 'Stephen King', 6, '1986', 'Egy csapat gyerek szembeszáll egy alakváltó gonosszal, amely évtizedenként visszatér, hogy rettegésben tartsa Derry városát.', 5),
(2, 'Az őrület hegyei', 'H.P. Lovecraft', 7, '1936', 'Egy antarktiszi expedíció rémálommá válik, amikor ősi, földöntúli lények nyomaira bukkannak.', 7),
(3, 'Velünk véget ér ', 'Colleen Hoover', 5, '2016', 'Lily egy nehéz múlt után új életet kezd Bostonban, ahol találkozik a sármos és titokzatos idegsebész, Ryle Kincaid-del. Szenvedélyes kapcsolatuk azonban komoly kihívások elé kerül, amikor Lily múltjából felbukkan első szerelme, Atlas.', 5),
(4, 'Szerelmünk lapjai', 'Nicholas Sparks', 8, '1996', ' Egy idős férfi meséli el egy fiatal szerelmespár történetét, akik társadalmi különbségeik ellenére mélyen egymásba szeretnek. A sors azonban közbeszól, és évek múlva újra szembe kell nézniük az érzéseikkel.', 8),
(5, 'Beach Read – Strandkönyv', 'Emily Henry', 5, '2020', 'January és Gus két író, akik szomszédok lesznek egy tóparti házban. Mindketten alkotói válságban vannak, így egy fogadást kötnek: kipróbálják egymás műfaját. Az együtt töltött idő alatt nemcsak az írásban segítik egymást, hanem az érzelmeik is egyre mélyebbé válnak.', 5),
(6, 'A katedrális', 'Ken Follett', 10, '1989', 'A 12. századi Angliában játszódó epikus történet egy katedrális építéséről szól, miközben a szereplők – kőművesek, nemesek és szerzetesek – hatalmi harcokba, árulásba és szerelmi viszályokba keverednek.', 10),
(7, 'Pompeji', 'Robert Harris', 7, '2003', 'A regény az időszámításunk szerinti 79-ben, a Vezúv kitörése előtti napokban játszódik. A fiatal vízmérnök, Attilius versenyt fut az idővel, hogy megértse a földmozgásokat, miközben a korrupció és politikai cselszövések is veszélyeztetik küldetését.', 7),
(8, 'Az éjszakai angyal', 'Kristin Hannah', 6, '2015', 'A második világháború idején két francia nővér, Vianne és Isabelle életútja fonódik össze a háború borzalmai közepette. Egyikük a családját próbálja megóvni, míg a másik az ellenállásban vállal életveszélyes szerepet.', 6),
(9, 'Dűne', 'Frank Herbert', 8, '1965', 'A távoli jövőben játszódó történet a sivatagos Arrakis bolygón zajlik, ahol a hatalmi harcok középpontjában a létfontosságú \"fűszer\" áll. Paul Atreides herceg sorsa összefonódik a bolygó titkaival és az őslakos fremenekkel.', 8),
(10, 'Alapítvány', 'Isaac Asimov', 7, '1951', ' A Galaktikus Birodalom hanyatlását egy zseniális matematikus, Hari Seldon próbálja előre jelezni és irányítani pszichohistória nevű tudományával. Az Alapítvány létrehozásával igyekszik lerövidíteni a közelgő sötét korszakot.', 7),
(11, 'A marsi', 'Andy Weir', 6, '2011', 'Mark Watney, egy marsi expedíció asztronautája egy baleset után egyedül marad a vörös bolygón. Korlátozott erőforrásokkal próbál túlélni, miközben a NASA és a világ összefog a megmentéséért.', 6),
(12, 'Száz év magány', 'Gabriel García Márquez', 6, '1967', 'A Buendía család hét generációjának történetét követi végig a mágikus realizmus eszközeivel. A fiktív Macondo városában a szereplők sorsa ismétlődő mintákban fonódik össze, miközben a történelem, a szerelem és a magány örök témái bontakoznak ki.', 6),
(13, 'Bűn és bűnhődés', 'Fyodor Dosztojevszkij', 7, '0000', 'Rogyion Raszkolnyikov, egy elszegényedett diák, megöli egy uzsorásasszonyt, hogy igazolja saját filozófiai elméletét. A gyilkosság utáni lelki gyötrődése és a nyomozás pszichológiai feszültsége teszi a művet a bűntudat és a megváltás egyik legnagyobb irodalmi elemzésévé.', 7),
(14, 'Saját szoba', 'Virginia Woolf', 5, '1929', 'Az esszéregény a nők és az irodalom kapcsolatát vizsgálja, kifejtve, hogy a női írók érvényesüléséhez pénzügyi függetlenségre és egy saját térre van szükségük. A mű feminista gondolkodás egyik alapműve, amely máig aktuális kérdéseket feszeget.', 5),
(15, 'Sapiens: Az emberiség rövid története', 'Yuval Noah Harari', 5, '2011', 'A könyv az emberiség fejlődését mutatja be az őskortól napjainkig, kitérve a társadalmak, vallások, gazdasági rendszerek és technológiák kialakulására. Olvasmányos stílusban tárja elénk az emberi faj történetét és jövőbeli kihívásait.', 5),
(16, 'A kis herceg', 'Antoine de Saint-Exupéry', 7, '1943', 'Egy kisfiú kalandjait követhetjük nyomon, aki elhagyja bolygóját, és különböző figurákkal találkozik az univerzumban. A könyv mély filozófiai és emberi tanulságokat rejt, egyszerre szól gyerekekhez és felnőttekhez.', 7),
(17, 'Salt, Fat, Acid, Heat ', 'Samin Nosrat', 8, '2017', ' mutatja be, hogy az olvasók megértsék az ízek egyensúlyát és a főzés alapjait.', 8),
(18, 'Kitchen Confidential: Adventures in the Culinary Underbelly', 'Anthony Bourdain', 7, '2000', ' A híres séf őszinte és szórakoztató memoárja a vendéglátóipar sötétebb oldaláról, tele belsős történetekkel és konyhai titkokkal.', 7),
(19, 'Plenty', 'Yotam Ottolenghi', 6, '2010', '', 6),
(20, 'Batman: The Killing Joke', 'Alan Moore, Brian Bolland', 6, '1988', 'Egy sötét és pszichológiai mélységű Batman-történet, amely bemutatja Joker eredettörténetét és az őrület természetét vizsgálja.', 6),
(21, 'Spider-Man: Kraven\'s Last Hunt', 'J.M. DeMatteis, Mike Zeck', 5, '1987', 'Kraven, a Vadász utolsó és legnagyobb kihívása Pókember ellen. Egy sötét és komor történet, amely az identitás és a győzelem témáját járja körbe.', 5),
(22, 'Watchmen', 'Alan Moore, Dave Gibbons', 9, '1986', 'Egy alternatív történelmi világban játszódó képregény, amely a szuperhősök morális dilemmáit és az emberi természetet boncolgatja.', 9);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `helye`
--
ALTER TABLE `helye`
  ADD PRIMARY KEY (`id`),
  ADD KEY `konyvId` (`konyvId`);

--
-- A tábla indexei `kolcsonzes`
--
ALTER TABLE `kolcsonzes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `konyvId` (`konyvId`),
  ADD KEY `kolcsonzoId` (`kolcsonzoId`);

--
-- A tábla indexei `kolcsonzo`
--
ALTER TABLE `kolcsonzo`
  ADD PRIMARY KEY (`kolcsonzoId`);

--
-- A tábla indexei `konyv`
--
ALTER TABLE `konyv`
  ADD PRIMARY KEY (`konyvId`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `helye`
--
ALTER TABLE `helye`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT a táblához `kolcsonzes`
--
ALTER TABLE `kolcsonzes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT a táblához `kolcsonzo`
--
ALTER TABLE `kolcsonzo`
  MODIFY `kolcsonzoId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `konyv`
--
ALTER TABLE `konyv`
  MODIFY `konyvId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `helye`
--
ALTER TABLE `helye`
  ADD CONSTRAINT `helye_ibfk_1` FOREIGN KEY (`konyvId`) REFERENCES `konyv` (`konyvId`);

--
-- Megkötések a táblához `kolcsonzes`
--
ALTER TABLE `kolcsonzes`
  ADD CONSTRAINT `kolcsonzes_ibfk_1` FOREIGN KEY (`konyvId`) REFERENCES `konyv` (`konyvId`),
  ADD CONSTRAINT `kolcsonzes_ibfk_2` FOREIGN KEY (`kolcsonzoId`) REFERENCES `kolcsonzo` (`kolcsonzoId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
